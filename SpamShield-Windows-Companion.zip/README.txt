========================================================================
   AI SPAM & NEWS DETECTOR - WINDOWS NOTIFICATION COMPANION
========================================================================

HOW TO USE ON ANY WINDOWS LAPTOP:

1. Right-click the downloaded ZIP file and choose "Extract All...".
2. Open the extracted folder and double-click "run.bat".
3. A terminal window will open showing:
   "[OK] WinRT Notification Listener: Available"
   "[OK] Windows Notification Access Status: Allowed"
4. Your default browser will automatically open your live dashboard:
   https://ai-spam-message-news-detector.vercel.app

5. That's it! As long as the "run.bat" window is open, incoming WhatsApp
   and Windows notifications will be automatically captured, scanned,
   and scored for spam, phishing, and fake news on your live website.

TROUBLESHOOTING PERMISSION DENIED:
- If Windows says "Access Denied", open:
  Settings -> System (or Privacy & Security) -> Notifications
  and ensure "Notifications" are switched ON for WhatsApp and your apps.
========================================================================
