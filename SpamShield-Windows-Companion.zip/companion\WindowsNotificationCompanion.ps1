<#
.SYNOPSIS
    AI Spam, Message & News Detector - Windows Notification Companion Server
.DESCRIPTION
    A lightweight, local Windows companion that connects the Windows 10/11
    UserNotificationListener WinRT API to the local AI Spam & News Detector web app.
    
    Operates strictly on 127.0.0.1 (local loopback).
    Zero external network telemetry. Zero persistent logging of messages.
#>

param(
    [int]$Port = 8765,
    [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  AI Spam, Message & News Detector - Windows Companion   " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host ""

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir

# Check Windows Version and WinRT Notification Listener availability
$WinRTOk = $false
$AccessStatus = "Unsupported"
$Listener = $null

try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime -ErrorAction Stop
    [Windows.UI.Notifications.Management.UserNotificationListener, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
    $Listener = [Windows.UI.Notifications.Management.UserNotificationListener]::Current
    $WinRTOk = ($Listener -ne $null)
    if ($WinRTOk) {
        $AccessStatus = $Listener.GetAccessStatus().ToString()
    }
} catch {
    $WinRTOk = $false
    $AccessStatus = "WinRT Load Error: $_"
}

Write-Host "[INFO] WinRT UserNotificationListener: " -NoNewline
if ($WinRTOk) {
    Write-Host "Available" -ForegroundColor Green
    Write-Host "[INFO] Windows Notification Access Status: " -NoNewline
    if ($AccessStatus -eq "Allowed") {
        Write-Host "Allowed (Ready to monitor notifications)" -ForegroundColor Green
    } elseif ($AccessStatus -eq "Denied") {
        Write-Host "Denied (Permission needed in Windows Settings)" -ForegroundColor Yellow
    } else {
        Write-Host "$AccessStatus" -ForegroundColor Yellow
    }
} else {
    Write-Host "Unavailable (Requires Windows 10 build 1607+ or Windows 11)" -ForegroundColor Yellow
}

# In-memory history and sequence for notifications
$GlobalSequence = 0
$NotificationHistory = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
$SeenNotificationIds = [System.Collections.Generic.HashSet[string]]::new()

# Function to safely extract notification text from WinRT Notification object
function Get-NotificationDetails($notif) {
    $id = "$($notif.Id)"
    $app = "Windows App"
    $title = ""
    $body = ""
    $isUnavailable = $false

    try {
        if ($notif.AppInfo -and $notif.AppInfo.DisplayInfo) {
            $appName = $notif.AppInfo.DisplayInfo.DisplayName
            if (-not [string]::IsNullOrWhiteSpace($appName)) {
                $app = [string]$appName
            }
        }
    } catch {}

    try {
        $visual = $notif.Notification.Visual
        $bindings = $visual.GetBinding([Windows.UI.Notifications.KnownNotificationBindings]::ToastGeneric)
        if ($bindings) {
            $textList = @($bindings.GetTextElements())
            if ($textList.Length -gt 0) {
                $t = $textList[0].Text
                if ($t) { $title = [string]$t }
            }
            if ($textList.Length -gt 1) {
                $bodyParts = @()
                for ($i = 1; $i -lt $textList.Length; $i++) {
                    $bt = $textList[$i].Text
                    if ($bt) { $bodyParts += [string]$bt }
                }
                $body = [string]($bodyParts -join " ")
            }
        }
    } catch {
        $isUnavailable = $true
    }

    # Prevent feedback loops: Skip recursive notifications created by agent / browser echo / alerts
    if ($title -match "AI (?:Alert|Shield|Spam)" -or $body -match "AI (?:Alert|Shield|Spam)" -or $title -match "Test Pop-up" -or $app -match "ai-spam-message-news-detector" -or $app -match "Antigravity" -or $title -match "Requesting your permission" -or $title -match "(?:Microsoft Edge|Google Chrome):\s*(?:Microsoft Edge|Google Chrome):") {
        return $null
    }

    # Check for WhatsApp package family, App ID, AUMID, or WhatsApp Web signatures
    try {
        $aumid = ""
        if ($notif.AppInfo -and $notif.AppInfo.AppUserModelId) { $aumid = [string]$notif.AppInfo.AppUserModelId }
        $appId = ""
        if ($notif.AppInfo -and $notif.AppInfo.Id) { $appId = [string]$notif.AppInfo.Id }
        
        if ($aumid -match "WhatsApp" -or $aumid -match "5319275A" -or $appId -match "WhatsApp" -or $app -match "WhatsApp" -or 
            $aumid -eq "Chrome.5AQTQITLTALIS66JT7RCRTTDYQ" -or ($title -match "web\.whatsapp\.com") -or 
            ($title -match "(?i)WhatsApp") -or ($body -match "^~.*:" -and $app -match "Chrome|Edge|Browser")) {
            $app = "WhatsApp"
        }
    } catch {}

    if ([string]::IsNullOrWhiteSpace($title) -and [string]::IsNullOrWhiteSpace($body)) {
        $isUnavailable = $true
        $body = "[Content Unavailable: Omitted by Windows privacy settings]"
    }

    return @{
        id = [string]$id
        sourceApp = [string]$app
        title = [string]$title
        body = [string]$body
        isUnavailable = [bool]$isUnavailable
        timestamp = (Get-Date).ToString("o")
    }
}

# Function to poll WinRT notifications when allowed
function Sync-WindowsNotifications {
    if (-not $WinRTOk -or -not $Listener) { return }
    try {
        $currentStatus = $Listener.GetAccessStatus().ToString()
        if ($currentStatus -ne "Allowed") { return }

        # Query Toast notifications asynchronously
        $op = $Listener.GetNotificationsAsync([Windows.UI.Notifications.NotificationKinds]::Toast)
        $method = $Listener.GetType().GetMethod('GetNotificationsAsync', [Type[]]@([Windows.UI.Notifications.NotificationKinds]))
        $genericArg = $method.ReturnType.GetGenericArguments()[0]

        $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
            $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*'
        }[0]

        if ($asTask -and $genericArg) {
            $boundAsTask = $asTask.MakeGenericMethod(@($genericArg))
            $task = $boundAsTask.Invoke($null, @($op))
            $task.Wait(1200)
            if ($task.IsCompleted -and -not $task.IsFaulted -and $task.Result) {
                $notifs = $task.Result
                foreach ($n in $notifs) {
                    $nId = "$($n.Id)"
                    if (-not $SeenNotificationIds.Contains($nId)) {
                        [void]$SeenNotificationIds.Add($nId)
                        $item = Get-NotificationDetails($n)
                        if ($null -eq $item) { continue }
                        $seq = [System.Threading.Interlocked]::Increment([ref]$GlobalSequence)
                        $item["sequence"] = $seq
                        [void]$NotificationHistory.Add($item)
                        while ($NotificationHistory.Count -gt 200) {
                            $NotificationHistory.RemoveAt(0)
                        }
                        Write-Host "[TOAST CAPTURED] App: $($item.sourceApp) | Title: $($item.title) | Length: $($item.body.Length) chars | Seq: $seq" -ForegroundColor Green
                    }
                }
            }
        }
    } catch {
        # Suppress poll errors
    }
}

# Content-type mapping for serving static frontend files
$MimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".svg"  = "image/svg+xml"
    ".ico"  = "image/x-icon"
}

# Start TCP HTTP Server (Binds to all network interfaces so other laptops & mobiles on Wi-Fi can connect)
$ListenIp = [System.Net.IPAddress]::Any
$TcpServer = New-Object System.Net.Sockets.TcpListener($ListenIp, $Port)

# Detect local LAN IP for multi-device Wi-Fi pairing
$LanIp = "127.0.0.1"
try {
    $hostName = [System.Net.Dns]::GetHostName()
    $addresses = [System.Net.Dns]::GetHostAddresses($hostName)
    foreach ($addr in $addresses) {
        if ($addr.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork -and -not $addr.ToString().StartsWith("127.")) {
            $LanIp = $addr.ToString()
            break
        }
    }
} catch {}

$ServerUrl = "http://127.0.0.1:$Port"
$LanUrl = "http://${LanIp}:$Port"

try {
    $TcpServer.Start()
} catch {
    Write-Host "[INFO] Windows Companion is already active on port $Port." -ForegroundColor Green
    Write-Host "Opening $ServerUrl in your default browser..." -ForegroundColor Cyan
    if (-not $NoBrowser) {
        try { Start-Process "http://127.0.0.1:$Port" } catch {}
    }
    exit 0
}

Write-Host ""
Write-Host "[SUCCESS] Windows Companion listening on port $Port!" -ForegroundColor Green
Write-Host "  -> On this PC:                    $ServerUrl" -ForegroundColor Cyan
Write-Host "  -> Other Laptops & Mobile (Wi-Fi): $LanUrl" -ForegroundColor Cyan
Write-Host "[SECURITY] Local network loopback (127.0.0.1). Zero cloud telemetry." -ForegroundColor Gray
Write-Host ""

if (-not $NoBrowser) {
    try {
        Start-Process $ServerUrl
    } catch {}
}

Write-Host "Press Ctrl+C in this console to stop the companion." -ForegroundColor Gray
Write-Host ""

try {
    while ($true) {
        if ($TcpServer.Pending()) {
            $client = $TcpServer.AcceptTcpClient()
            try {
                $stream = $client.GetStream()
                $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)

                $reqLine = $reader.ReadLine()
                if ([string]::IsNullOrEmpty($reqLine)) {
                    continue
                }

            $parts = $reqLine.Split(' ')
            $method = $parts[0]
            $urlPath = if ($parts.Length -gt 1) { $parts[1] } else { "/" }
            $route = $urlPath.Split('?')[0]

            # Read headers
            $headers = @{}
            $contentLength = 0
            while ($line = $reader.ReadLine()) {
                if ($line -eq "") { break }
                $headerParts = $line.Split(':', 2)
                if ($headerParts.Length -eq 2) {
                    $key = $headerParts[0].Trim().ToLower()
                    $val = $headerParts[1].Trim()
                    $headers[$key] = $val
                    if ($key -eq "content-length") {
                        [int]::TryParse($val, [ref]$contentLength) | Out-Null
                    }
                }
            }

            # Read Body if POST
            $body = ""
            if ($contentLength -gt 0) {
                $buffer = New-Object char[] $contentLength
                $totalRead = 0
                while ($totalRead -lt $contentLength) {
                    $read = $reader.Read($buffer, $totalRead, $contentLength - $totalRead)
                    if ($read -le 0) { break }
                    $totalRead += $read
                }
                $body = New-Object string($buffer, 0, $totalRead)
            }

            # CORS Pre-flight with Private Network Access support
            if ($method -eq "OPTIONS") {
                $respHeader = "HTTP/1.1 204 No Content`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Headers: Content-Type, Accept`r`nAccess-Control-Allow-Private-Network: true`r`nConnection: close`r`n`r`n"
                $respBytes = [System.Text.Encoding]::UTF8.GetBytes($respHeader)
                $stream.Write($respBytes, 0, $respBytes.Length)
                $stream.Flush()
                $client.Close()
                continue
            }

            # --- API ROUTES ---
            if ($route -eq "/api/status" -or $route -eq "/status") {
                Sync-WindowsNotifications
                $curStatus = if ($Listener) { $Listener.GetAccessStatus().ToString() } else { "Unsupported" }
                $statusPayload = @{
                    companion = "running"
                    version = "1.0.0"
                    winrtAvailable = $WinRTOk
                    winrtPermission = $curStatus
                    platform = "Windows"
                    osVersion = [System.Environment]::OSVersion.VersionString
                    timestamp = (Get-Date).ToString("o")
                    info = "Local companion operating securely on loopback."
                } | ConvertTo-Json

                $respBytes = [System.Text.Encoding]::UTF8.GetBytes($statusPayload)
                $header = "HTTP/1.1 200 OK`r`nContent-Type: application/json`r`nContent-Length: $($respBytes.Length)`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Headers: Content-Type, Accept`r`nAccess-Control-Allow-Private-Network: true`r`nConnection: close`r`n`r`n"
                $hBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
                $stream.Write($hBytes, 0, $hBytes.Length)
                $stream.Write($respBytes, 0, $respBytes.Length)
                $stream.Flush()
                $client.Close()
                continue
            }

            if (($route -eq "/api/request-permission" -or $route -eq "/api/notifications/request-access") -and $method -eq "POST") {
                $reqSuccess = $false
                $msg = ""
                try {
                    # Launch Windows Notifications Privacy Settings page
                    Start-Process "ms-settings:privacy-notifications"
                    $reqSuccess = $true
                    $msg = "Opened Windows Notification privacy settings. Please grant access under 'Let apps access your notifications'."
                } catch {
                    $msg = "Unable to open Windows Settings automatically: $_"
                }

                $respData = @{
                    success = $reqSuccess
                    message = $msg
                    winrtPermission = if ($Listener) { $Listener.GetAccessStatus().ToString() } else { "Unsupported" }
                } | ConvertTo-Json

                $respBytes = [System.Text.Encoding]::UTF8.GetBytes($respData)
                $header = "HTTP/1.1 200 OK`r`nContent-Type: application/json`r`nContent-Length: $($respBytes.Length)`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Headers: Content-Type, Accept`r`nAccess-Control-Allow-Private-Network: true`r`nConnection: close`r`n`r`n"
                $hBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
                $stream.Write($hBytes, 0, $hBytes.Length)
                $stream.Write($respBytes, 0, $respBytes.Length)
                $stream.Flush()
                $client.Close()
                continue
            }

            if (($route -eq "/api/notifications" -or $route -eq "/api/notifications/poll") -and $method -eq "GET") {
                Sync-WindowsNotifications

                # Parse 'since' query parameter
                $sinceSeq = 0
                if ($urlPath -match "[\?&]since=(\d+)") {
                    [int]::TryParse($matches[1], [ref]$sinceSeq) | Out-Null
                }

                $snapshot = [System.Object[]]$NotificationHistory.ToArray()
                $batch = @()
                if ($sinceSeq -gt 0) {
                    $batch = @($snapshot | Where-Object { $_.sequence -gt $sinceSeq })
                } else {
                    $batch = @($snapshot | Select-Object -Last 50)
                }

                $maxSeq = if ($batch.Count -gt 0) {
                    $batch[-1].sequence
                } else {
                    $sinceSeq
                }
                if (-not $maxSeq -or $maxSeq -eq 0) { $maxSeq = $GlobalSequence }

                $respData = @{
                    success = $true
                    notifications = @($batch)
                    count = $batch.Count
                    sequence = $maxSeq
                } | ConvertTo-Json -Depth 4

                $respBytes = [System.Text.Encoding]::UTF8.GetBytes($respData)
                $header = "HTTP/1.1 200 OK`r`nContent-Type: application/json`r`nContent-Length: $($respBytes.Length)`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Headers: Content-Type, Accept`r`nAccess-Control-Allow-Private-Network: true`r`nConnection: close`r`n`r`n"
                $hBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
                $stream.Write($hBytes, 0, $hBytes.Length)
                $stream.Write($respBytes, 0, $respBytes.Length)
                $stream.Flush()
                $client.Close()
                continue
            }

            if (($route -eq "/api/notifications/simulate" -or $route -eq "/api/sms/submit" -or $route -eq "/api/notifications/submit") -and $method -eq "POST") {
                $simObj = @{
                    id = "msg_" + (Get-Date).Ticks
                    sourceApp = "Mobile SMS"
                    title = "Incoming SMS"
                    body = "Sample test notification text"
                    isUnavailable = $false
                    timestamp = (Get-Date).ToString("o")
                }
                if (-not [string]::IsNullOrEmpty($body)) {
                    try {
                        $parsed = $body | ConvertFrom-Json
                        if ($parsed.sourceApp) { $simObj.sourceApp = [string]$parsed.sourceApp }
                        if ($parsed.title) { $simObj.title = [string]$parsed.title }
                        if ($parsed.body) { $simObj.body = [string]$parsed.body }
                        if ($parsed.isUnavailable -ne $null) { $simObj.isUnavailable = [bool]$parsed.isUnavailable }
                    } catch {}
                }

                $seq = [System.Threading.Interlocked]::Increment([ref]$GlobalSequence)
                $simObj["sequence"] = $seq
                [void]$NotificationHistory.Add($simObj)
                while ($NotificationHistory.Count -gt 200) {
                    $NotificationHistory.RemoveAt(0)
                }

                $respData = @{
                    success = $true
                    message = "Simulated notification queued"
                    notification = $simObj
                } | ConvertTo-Json -Depth 4

                $respBytes = [System.Text.Encoding]::UTF8.GetBytes($respData)
                $header = "HTTP/1.1 200 OK`r`nContent-Type: application/json`r`nContent-Length: $($respBytes.Length)`r`nAccess-Control-Allow-Origin: *`r`nConnection: close`r`n`r`n"
                $hBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
                $stream.Write($hBytes, 0, $hBytes.Length)
                $stream.Write($respBytes, 0, $respBytes.Length)
                $stream.Flush()
                $client.Close()
                continue
            }

            # --- STATIC FILE SERVING ---
            $cleanPath = $urlPath.Split('?')[0].TrimStart('/')
            if ([string]::IsNullOrEmpty($cleanPath)) { $cleanPath = "index.html" }
            $cleanPath = $cleanPath -replace '/', '\'

            $filePath = Join-Path $ProjectRoot $cleanPath
            if (Test-Path -Path $filePath -PathType Leaf) {
                $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
                $mime = if ($MimeTypes.ContainsKey($ext)) { $MimeTypes[$ext] } else { "application/octet-stream" }
                $fileBytes = [System.IO.File]::ReadAllBytes($filePath)
                $header = "HTTP/1.1 200 OK`r`nContent-Type: $mime`r`nContent-Length: $($fileBytes.Length)`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Private-Network: true`r`nConnection: close`r`n`r`n"
                $hBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
                $stream.Write($hBytes, 0, $hBytes.Length)
                $stream.Write($fileBytes, 0, $fileBytes.Length)
            } else {
                $notFound = "<h1>404 Not Found</h1><p>File $urlPath not found.</p>"
                $nfBytes = [System.Text.Encoding]::UTF8.GetBytes($notFound)
                $header = "HTTP/1.1 404 Not Found`r`nContent-Type: text/html`r`nContent-Length: $($nfBytes.Length)`r`nConnection: close`r`n`r`n"
                $hBytes = [System.Text.Encoding]::UTF8.GetBytes($header)
                $stream.Write($hBytes, 0, $hBytes.Length)
                $stream.Write($nfBytes, 0, $nfBytes.Length)
            }

            $stream.Flush()
            } catch {
                # Connection was aborted or closed by client - safe to ignore
            } finally {
                try { $client.Close() } catch {}
            }
        } else {
            Start-Sleep -Milliseconds 50
        }
    }
} finally {
    $TcpServer.Stop()
    Write-Host "`nCompanion server stopped cleanly." -ForegroundColor Yellow
}
